//scripts.js
//---------------------------------Global Functions Used On More Than One Page-----------------------------//
//Function for navigation dropdowns.  This is called from each page in a document ready function
function enhanceNavigation () {
    var links = document.getElementsByTagName("a");
    for (var i = 0; i < links.length; i++) {
        if (links[i].className.indexOf("menulink") > -1) {
            links[i].onclick = function () { return false; }
            links[i].onmouseover = function () { // toggleMenu
                var startMenu = this.href.lastIndexOf("/") + 1;
                var stopMenu = this.href.lastIndexOf(".");
                var thisMenuName = this.href.substring(startMenu, stopMenu);

                document.getElementById(thisMenuName).style.display = "block";

                this.parentNode.className = thisMenuName;
                this.parentNode.onmouseout = function () { //toggleDivOff;
                    document.getElementById(this.className).style.display = "none";
                }
                this.parentNode.onmouseover = function () {  //toggleDivOn;
                    document.getElementById(this.className).style.display = "block";
                }
            }
        }
    }
}
//---------------------------------Home Page Functions-----------------------------//
//Functions to get cookie 
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}
//Function to check if PlotzkerCookie exists, if not creates one, if so increments the counter value
function checkSetCookie() {
    var cookieCounter = 0;
    var visitCount = getCookie("PlotzkerCookie");
    if(visitCount != "") {
        cookieCounter = parseInt(visitCount)+1;
    }
    else {
        cookieCounter = 1;
    }
    var d = new Date();
    d.setTime(d.getTime()+ (100*24*60*60*1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = "PlotzkerCookie=" + cookieCounter + "; " + expires;
    
    if (cookieCounter == 1) {
        $("#PCookieCount").html("This looks like your first visit.<br /><br /> Welcome!");
    }
    else if (cookieCounter < 5) { 
        $("#PCookieCount").html("<p>Welcome back! <br /><br />Number of visits: " + cookieCounter + "</p>");
    }
    else {
        $("#PCookieCount").html("<p>Number of visits: " + cookieCounter + "</p><p>You must really love this site!</p>");
    }
}
function playSlideshow() {
    var t1 = 8000;
    var t2 = 12010;
    var t3 = 20010;
    var t4 = 24015;
    var t5 = 32015;
    var t6 = 36020;
    var t7 = 44020;
    var t8 = 48025;

    for (i = 0; i < 100; i++) {
        setTimeout(function(){
            $("#InnerContentDiv").fadeOut(4000);
        }, t1);
        setTimeout(function(){
            $("#CubsPhotoDiv").show();
        }, t2);
        setTimeout(function(){
            $("#CubsPhotoDiv").fadeOut(4000);
        }, t3);
        setTimeout(function(){
            $("#CharliePhotoDiv").show();
        }, t4);
        setTimeout(function(){
            $("#CharliePhotoDiv").fadeOut(4000);
        }, t5);
        setTimeout(function(){
            $("#IkePhotoDiv").show();
        }, t6);
        setTimeout(function(){
            $("#IkePhotoDiv").fadeOut(4000);
        }, t7);
        setTimeout(function(){
            $("#InnerContentDiv").show();
        }, t8);
    }
}
//---------------------------------Form Page Functions-----------------------------//
//Global variables needed for checking code in two different functions
var code = "";
var myCode = "";
//Function to get new code upon page load and reset button press.
function getNewCode() {
    $("#TBCode").val("");
    var pool = ["A", "B", "C", "ABC", "AB", "AC", "BC"];
    var randomNumber = Math.floor(Math.random() * pool.length);
    $("#TBCode").val(pool[randomNumber]);
    code = $("#TBCode").val();
    
}
//function to clear error messages from form 
function ClearMessages() { 
    $("#SpanFirstName").html("");
    $("#SpanLastName").html("");
    $("#SpanBirthdate").html("");
    $("#SpanPhoneNumber").html("");
    $("#SpanGender").html("");
    $("#SpanSport").html("");
    $("#SpanTeam").html("");
    $("#SpanOutlook").html("");
    $("#BaseballTeam").hide();
    $("#FootballTeam").hide();
    $("#BasketballTeam").hide();
    $("#SpanCode").html("");
    $("#SpanCorrectCode").html("").show();
    $("#DivMessage").html("");
    myCode = "";
    setTimeout(function(){
        getNewCode();
    }, 50); //This has to be delayed for code to display, otherwise the reset clears it after it is set.
    
}
//functions to clear error messages on entry (onchange) without hitting submit
function clearFNameError(){
    $("#SpanFirstName").html("");
}
function clearLNameError(){
    $("#SpanLastName").html("");
}
function clearDateError(){
    $("#SpanBirthdate").html("");
}
function clearPhoneError(){
    $("#SpanPhoneNumber").html("");
}
function clearGenderError(){
    $("#SpanGender").html("");
}
function clearOutlookError(){
    $("#SpanOutlook").html("");
}
function clearTeamError(){
    $("#SpanTeam").html("");
}
//Function to show/hide/clear team divs, depending on which sport is chosen
function pickTeam(){
    if ($("#DDSport option:selected").val() == "Baseball"){
        $("#DivTeams").show();
        $("#DDFootballTeam").val("init");
        $("#FootballTeam").hide();
        $("#DDBasketballTeam").val("init");
        $("#BasketballTeam").hide();
        $("#BaseballTeam").show();
        $("#SpanSport").html("");
    }
    if ($("#DDSport option:selected").val() == "Football"){ 
        $("#DivTeams").show();
        $("#DDBasketballTeam").val("init");
        $("#BasketballTeam").hide();
        $("#DDBaseballTeam").val("init");
        $("#BaseballTeam").hide();
        $("#FootballTeam").show();
        $("#SpanSport").html("");
    }
    if ($("#DDSport option:selected").val() == "Basketball"){
        $("#DivTeams").show();
        $("#DDFootballTeam").val("init");
        $("#FootballTeam").hide();
        $("#DDBaseballTeam").val("init");
        $("#BaseballTeam").hide();
        $("#BasketballTeam").show();
        $("#SpanSport").html("");
    }
    if ($("#DDSport option:selected").val() == "init"){
        $("#SpanTeam").html("");
        $("#DivTeams").hide();
        $("#DDFootballTeam").val("init");
        $("#FootballTeam").hide();
        $("#DDBaseballTeam").val("init");
        $("#BaseballTeam").hide();
        $("#DDBasketballTeam").val("init");
        $("#BasketballTeam").hide();
    }
}
//function to determine if all fields have valid data upon submission of form
function Validate() {
    ClearMessages();
    //variables to use for comparing birthdate to the current date
    var pickedBirthDate = $("#TBDate").datepicker("getDate");
    var todaysDate = new Date();
    todaysDate.setHours(0,0,0,0);  //Sets time to 0, to allow scheduling same day appointments
    var isValid = true;

    if ($("#TBFirstName").val().length == 0) {
        isValid = false;
        $("#SpanFirstName").html("*");
    }
    if ($("#TBLastName").val().length == 0) {
        isValid = false;
        $("#SpanLastName").html("*");
    }
    if ($("#TBDate").val().length == 0) {
        isValid = false;
        $("#SpanBirthdate").html("*");
    }
    if  (pickedBirthDate > todaysDate) {
        isValid = false;
        $("#SpanBirthdate").html("Are you sure?");
    }
    if (($("#TBPhoneNumber").val().length == 0) || (isNonNumeric($("#TBPhoneNumber").val()) == true)) {
        isValid = false;
        $("#SpanPhoneNumber").html("*");
    }
    if ((!($("#RBMale").prop('checked'))) && (!($("#RBFemale").prop('checked')))) {
        isValid = false;
        $("#SpanGender").html("*");
    }
    if ($("#DDSport option:selected").val() == "init") {
        isValid = false;
        $("#SpanSport").html("*");
    } 
    //Checks all three sport dropdowns to see if all are empty
    if (($("#DDBaseballTeam option:selected").val() == "init") && ($("#DDFootballTeam option:selected").val() == "init") && ($("#DDBasketballTeam option:selected").val() == "init")) {
        isValid = false;
        $("#SpanTeam").html("Please select a team");
    } 
    if ((!($("#RBFull").prop('checked'))) && (!($("#RBEmpty").prop('checked')))) {
        isValid = false;
        $("#SpanOutlook").html("*");
    }
    //Checks the code checkboxes and assigns/appends them to myCode
    if ($("#CBA").is(':checked')){
        myCode += "A";
    }
    if ($("#CBB").is(':checked')){
        myCode += "B";
    }
    if ($("#CBC").is(':checked')){
        myCode += "C";
    }
    if (myCode != code){
        isValid = false;
        getNewCode();
        $("#SpanCode").html("&nbsp;&nbsp;Incorrect Code");
    }
    if(isValid == false){
       pickTeam();
       $("#DivMessage").html("Please Fix the Above Errors");
    }
    return isValid;
}
//Function to check code manually by pushing check code button
function checkCode(){
    myCode="";
    $("#SpanCorrectCode").html("");
    $("#SpanCode").html("");
    if ($("#CBA").is(':checked')){
        myCode += "A";
    }
    if ($("#CBB").is(':checked')){
        myCode += "B";
    }
    if ($("#CBC").is(':checked')){
        myCode += "C";
    }
    if (myCode != code){
        isValid = false;
        getNewCode();
        $("#SpanCode").html("&nbsp;&nbsp;Incorrect Code");
    }
    if (myCode == code){
        $("#SpanCorrectCode").show().html("Correct. You are not a robot!").css("color", "green").fadeOut(5000);
    }
}
//function to ensure the zip code and phone number are only numeric, or contain + - ( ) or a space
function isNonNumeric(tString) {
    validChars = " ()+-0123456789";
    
    for (var i = 0; i < tString.length; i++) {
        
        char = tString.charAt(i);
        if (validChars.indexOf(char) == -1) {
            return true;
        }
    }
    return false;
} 
function calculateAge() {
    //Gets birthdate from datepicker
    var birthDate = document.getElementById("TBDate").value;
    //Creates new Date object with birthdate
    var DOB = new Date(birthDate);
    //Gets month and day from birthdate
    var birthMonth = DOB.getUTCMonth() + 1; //months from 1-12
    var birthDay = DOB.getUTCDate();
    //Creates new Date object of current day
    var today = new Date();
    //Copy of today variable for age calculation.  
    //Sets time to end of day to avoid problem of age being one year too few
    var todayTest = today;
    todayTest.setHours(23, 59, 58, 0);
    //Calculates age by subtracting miliseconds of today and birthday
    var age = today.getTime() - DOB.getTime();

    //For debugging purposes.  Does not round down
    var ageTest = age;
    ageTest = (ageTest / (1000 * 60 * 60 * 24 * 365.25));

    //Converts age milliseconds to years
    age = Math.floor(age / (1000 * 60 * 60 * 24 * 365.25));
    //Gets current month 
    var currentMonth = today.getUTCMonth() + 1; //months from 1-12
    //Creates new Date object to be set to zero time.
    //Solves issue of date coming back one too high.
    var today2 = new Date();
    today2.setHours(0,0,0,0);
    var currentDay = today2.getUTCDate();
    //Sets hidden age textbox, to be passed by URL to response page.
    document.getElementById("TBAge").value = age;
    //Tests for match of birth month and birth day to current.
    //If so, prints Happy Bithday in hidden text box to be passed by URL to response page
    if((birthMonth == currentMonth) && (birthDay == currentDay)) {
       document.getElementById("TBBirthdayMessage").value = "Happy Birthday!!";
    }
}
//---------------------------------Results Page Functions-----------------------------//
//function to display results on results page
function DisplayResults() {
    $("#SpanFirstName").html(FixSpecialChars(GetUrlValue("first")));
    $("#SpanLastName").html(FixSpecialChars(GetUrlValue("last")));
    $("#SpanBirthdate").html(FixSpecialChars(GetUrlValue("date")));
    $("#SpanBirthdayMessage").html(FixSpecialChars(GetUrlValue("birthday")));
    $("#SpanAge").html(FixSpecialChars(GetUrlValue("age")));
    $("#SpanPhoneNumber").html(FixSpecialChars(GetUrlValue("phone")));
    $("#SpanGender").html(FixSpecialChars(GetUrlValue("RGGender")));
    displaySports();
    displayOutlook();
    displayFoods();
}
function displaySports(){
    var sport = "";
    var team = "";
    if (GetUrlValue("baseballteam") != "init") {
        sport = "baseball";
        team = FixSpecialChars(GetUrlValue("baseballteam"));
    }
    if (GetUrlValue("footballteam") != "init") {
        sport = "football";
        team = FixSpecialChars(GetUrlValue("footballteam"));
    }
    if (GetUrlValue("basketballteam") != "init") {
        sport = "basketball";
        team = FixSpecialChars(GetUrlValue("basketballteam"));
    }
    var sportMessage = "Your favorite " + sport + " team is: ";
    $("#SpanSport").html(sportMessage);
    $("#SpanTeam").html(team);
}
function displayOutlook() {
    var outlook = "";
    if (GetUrlValue("RGOutlook") == "Half-Full") {
        outlook = "Optimistic";
    }
    else {
        outlook = "Pessimistic";
    }
    $("#SpanOutlook").html(outlook);
}
function displayFoods() {
    var finalMessage1 = "";
    var finalMessage2 = "You have not selected any favorite foods";
    var singularMessage = "Your favorite food is: ";
    var pluralMessage = "The foods you enjoy are: ";
    var hobby = "";   
    
    if(GetUrlValue("Pizza") == "Pizza") {
        food = "Pizza";
        finalMessage1 = singularMessage; 
        finalMessage2 = food;
    }
    if(GetUrlValue("Hamburger") == "Hamburger") {
        if (finalMessage2 == "You have not selected any favorite foods") {
            food = "Hamburger";
            finalMessage1 = singularMessage; 
            finalMessage2 = food;
        }
        else {
            food += ", Hamburger";
            finalMessage1 = pluralMessage; 
            finalMessage2 = food;
        }
    }
    if(GetUrlValue("Salad") == "Salad") {
        if (finalMessage2 == "You have not selected any favorite foods") {
            food = "Salad";
            finalMessage1 = singularMessage; 
            finalMessage2 = food;
        }
        else {
            food += ", Salad";
            finalMessage1 = pluralMessage; 
            finalMessage2 = food;
        }
    }
    if(GetUrlValue("Steak") == "Steak") {
        if (finalMessage2 == "You have not selected any favorite foods") {
            food = "Steak";
            finalMessage1 = singularMessage; 
            finalMessage2 = food;
        }
        else {
            food += ", Steak";
            finalMessage1 = pluralMessage; 
            finalMessage2 = food;
        }
    }
    if(GetUrlValue("Cake") == "Cake") {
        if (finalMessage2 == "You have not selected any favorite foods") {
            food = "Cake";
            finalMessage1 = singularMessage; 
            finalMessage2 = food;
        }
        else {
            food += ", Cake";
            finalMessage1 = pluralMessage; 
            finalMessage2 = food;
        }
    }
    if(GetUrlValue("Pie") == "Pie") {
        if (finalMessage2 == "You have not selected any favorite foods") {
            food = "Pie";
            finalMessage1 = singularMessage; 
            finalMessage2 = food;
        }
        else {
            food += ", Pie";
            finalMessage1 = pluralMessage; 
            finalMessage2 = food;
        }
    }
    $("#SpanMessage1").html(finalMessage1);
    $("#SpanMessage2").html(finalMessage2);
}
//Gets URL variable from URL
function GetUrlValue(varSearch) {
    var searchString = window.location.search.substring(1);
    var variableArray = searchString.split('&'); //Split URL string on '&' symbol
    for (var i = 0; i < variableArray.length; i++) {
        var KeyValuePair = variableArray[i].split('='); //Loop through and split substrings on '=' symbol.
        if (KeyValuePair[0] == varSearch) { //If substring category is one you're looking for then return the value in the URL.
            return KeyValuePair[1]; //return found value.
        }
    }
}
//Function to replace special characters in url
function FixSpecialChars(data) {
    data = data.replace(/\+/g, " "); //To fix for + which is a space in the URL
    data = data.replace(/%2B/g, "+"); //To fix for a plus as data 
    data = data.replace(/%3D/g, "="); //To fix for an equals in data
    data = data.replace(/%3F/g, "?"); //To fix for a question mark in data.
    data = data.replace(/%21/g, "!"); //To fix for an exclamation point in data.
    data = data.replace(/%2F/g, "/"); //To fix for a forward slash.
    data = data.replace(/%5C/g, "\\"); //To fix for a backward slash.
    data = data.replace(/%28/g, "("); //To fix for a Open Parenthesis.
    data = data.replace(/%29/g, ")"); //To fix for a Close Parenthesis.
    data = data.replace(/%26/g, "&"); //To fix for an Ampersand.
    data = data.replace(/%23/g, "#"); //To fix for an pount sign.
    data = data.replace(/%24/g, "$"); //To fix for an dollar sign.
    data = data.replace(/%25/g, "%"); //To fix for an percent sign.
    data = data.replace(/%5E/g, "^"); //To fix for an caret.
    data = data.replace(/%3C/g, "<"); //To fix for a less than.
    data = data.replace(/%3E/g, ">"); //To fix for a greater than.
    data = data.replace(/%3A/g, ":"); //To fix for a colon.
    data = data.replace(/%3B/g, ";"); //To fix for a semi-colon.
    data = data.replace(/%27/g, "'"); //To fix for a single quote.
    data = data.replace(/%22/g, "\""); //To fix for a double quote.
    data = data.replace(/%2C/g, ","); //To fix for a comma.
    data = data.replace(/%7E/g, "~"); //To fix for a tilda.
    data = data.replace(/%60/g, "`"); //To fix for a backward apostrophe.
    data = data.replace(/%5B /g, "["); //To fix for a opening square bracket.
    data = data.replace(/%5D/g, "]"); //To fix for a closing square bracket.
    data = data.replace(/%7B/g, "{"); //To fix for a opening curly brace.
    data = data.replace(/%7D/g, "}"); //To fix for a closing curly brace.
    data = data.replace(/%7C/g, "|"); //To fix for a pipe.
    data = data.replace(/%40/g, "@"); //To fix for a @
    return (data);
} 
//---------------------------------Text Editor Page Functions-----------------------------//
//Function and handler for bold toggle button
function toggleBold(control) {
    if (control.style.color == "red") {
        $(control).css("color", "");
        $("#TAText").css("font-weight", "normal");
    }
    else {
        $(control).css("color", "red");
        $("#TAText").css("font-weight", "bold");
    } 
}
$("#BtnBold").click(function(){
    toggleBold(this); 
});
//Function and handler for italic toggle button 
function toggleItalic(control) {
    if (control.style.color == "red") {
        $(control).css("color", "");
        $("#TAText").css("font-style", "normal");
    }
    else {
        $(control).css("color", "red");
        $("#TAText").css("font-style", "italic");
    }
}
$("#BtnItalic").click(function () {
    toggleItalic(this);
});
//Function and handler for color choice dropdown
function changeColor(control){
    $("#TAText").css("color", control.value);
}
$("#DDColor").change(function(){
    changeColor(this);
});
//Function and handler for font size dropdown
function changeSize(control){
    $("#TAText").css("font-size", control.value);
}
$("#DDSize").change(function(){
    changeSize(this);
});
//Function and handler to count characters, words, and sentences
function textCount() {
    var count = new Array();
    var textString = $("#TAText").val();
    textString = textString.replace(/&nbsp;/g, "");  
    textString = textString.replace(/\"/g, "");  //strips out quotes 
    textString = textString.replace(/[?!]/g, "."); //ends each sentence with period
    $("#TBCharacters").val($("#TAText").val().length);
    if(textString == ""){      
        $("#TBWords").val("0");
    }
    else{
    $("#TBWords").val($("#TAText").val().split(" ").length); 
    }
    $("#TBSentences").val(textString.split(".").length-1);
}
$("#BtnWordCount").click(function(){
    textCount();
});


    
    